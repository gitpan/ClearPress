package t::view::derived;
use strict;
use warnings;
use base qw(ClearPress::view);

sub list_overridden {
}

sub list_overridden_ajax {
}

1;
