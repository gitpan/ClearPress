package t::view::error;
use strict;
use warnings;
use base qw(ClearPress::view::error);

1;
