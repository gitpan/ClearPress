
package GrandKids::view::child;
use strict;
use warnings;
use base qw(ClearPress::view);

1;
 
