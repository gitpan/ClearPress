
package GrandKids::view::family;
use strict;
use warnings;
use base qw(ClearPress::view);

1;
 
